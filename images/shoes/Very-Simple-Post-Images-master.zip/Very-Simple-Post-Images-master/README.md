#Very Simple Post Images

... is a Wordpress Plugin that makes adding adding images to a post gallery as simple as
possible.

We believe that the Media Libary UI is extremely powerful; but can be confusing to casual
users of Wordpress.

This plugin tackles that problem by embedding the most common operations that you want
to do with post images in a metabox right next to the post content.

* Upload multiple images
* Delete an image
* Select the featured image

##Screencast demo
[<img src="http://content.screencast.com/users/mrdavidlaing/folders/Jing/media/ddef4400-d1f4-47d6-8678-14ecd7a769ca/00000063.png">](http://www.youtube.com/watch?v=uE85rU6VyoU)


##We need your help

Please give us feedback via the 
[issue tracker](https://github.com/davidgtonge/Very-Simple-Post-Images/issues)
