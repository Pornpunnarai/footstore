=== Plugin Name ===
Contributors: davidgtonge, mrdavidlaing
Tags: image, ajax
Requires at least: 3.0
Tested up to: 3.1
Stable tag: trunk

WordPress Image Management Plugin

== Description ==

Longer Description
