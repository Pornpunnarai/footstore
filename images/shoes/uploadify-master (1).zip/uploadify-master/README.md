uploadify
=========

Hosting uploadify files.

Added jquery.uploadify.stripped.js which contains just the uploadify code, without the minified swfobject and swfupload.
